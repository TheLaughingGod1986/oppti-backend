<?php
/**
 * Core Ajax Billing Trait
 * Handles Stripe checkout and billing AJAX endpoints
 *
 * @package BeepBeep_AI
 * @since 5.0.0
 */

namespace BeepBeepAI\AltTextGenerator\Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; }

use BeepBeepAI\AltTextGenerator\Usage_Tracker;

trait Core_Ajax_Billing {

	/**
	 * AJAX handler: Persist first-touch marketing attribution.
	 */
	public function ajax_capture_attribution() {
		$action = 'beepbeepai_nonce';
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ?? '' ) ), $action ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid nonce.', 'beepbeep-ai-alt-text-generator' ) ), 403 );
			return;
		}
		if ( ! $this->user_can_manage() ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized', 'beepbeep-ai-alt-text-generator' ) ) );
			return;
		}

		if ( ! class_exists( '\BeepBeepAI\AltTextGenerator\BBAI_Attribution' ) ) {
			wp_send_json_success( array( 'stored' => false ) );
			return;
		}

		$payload = array();
		foreach ( \BeepBeepAI\AltTextGenerator\BBAI_Attribution::attribution_keys() as $key ) {
			if ( isset( $_POST[ $key ] ) ) {
				$payload[ $key ] = sanitize_text_field( wp_unslash( (string) $_POST[ $key ] ) );
			}
		}

		\BeepBeepAI\AltTextGenerator\BBAI_Attribution::maybe_capture( $payload );
		wp_send_json_success(
			array(
				'stored' => true,
				'keys'   => array_keys( \BeepBeepAI\AltTextGenerator\BBAI_Attribution::get_payload() ),
			)
		);
	}

	/**
	 * AJAX handler: Create Stripe checkout session
	 */
	public function ajax_create_checkout() {
		$action = 'beepbeepai_nonce';
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ?? '' ) ), $action ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid nonce.', 'beepbeep-ai-alt-text-generator' ) ), 403 );
			return;
		}
		if ( ! $this->user_can_manage() ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized', 'beepbeep-ai-alt-text-generator' ) ) );
			return;
		}

		$price_id = isset( $_POST['price_id'] ) ? sanitize_text_field( wp_unslash( $_POST['price_id'] ) ) : '';

		// Resolve plan_id to a Stripe price ID when price_id is not provided directly.
		if ( empty( $price_id ) ) {
			$plan_id        = isset( $_POST['plan_id'] ) ? sanitize_key( wp_unslash( $_POST['plan_id'] ) ) : '';
			$valid_plan_ids = array_keys( $this->get_checkout_price_ids() );
			if ( ! in_array( $plan_id, $valid_plan_ids, true ) ) {
				$plan_id = '';
			}
			if ( ! empty( $plan_id ) ) {
				$price_id = $this->get_checkout_price_id( $plan_id );
			}
		}

		if ( empty( $price_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Price ID is required', 'beepbeep-ai-alt-text-generator' ) ) );
			return;
		}

		$success_url = admin_url( 'upload.php?page=bbai&checkout=success' );
		$cancel_url  = admin_url( 'upload.php?page=bbai&checkout=cancel' );

		$result = $this->api_client->create_checkout_session( $price_id, $success_url, $cancel_url );

		if ( is_wp_error( $result ) ) {
			$error_message       = $result->get_error_message();
			$error_code          = $result->get_error_code();
			$error_message_lower = is_string( $error_message ) ? strtolower( $error_message ) : '';

			if ( 'auth_required' === $error_code ||
				strpos( $error_message_lower, 'session' ) !== false ||
				strpos( $error_message_lower, 'log in' ) !== false ) {
				$error_message = __( 'Unable to create checkout session. Please try again or contact support.', 'beepbeep-ai-alt-text-generator' );
			}

			wp_send_json_error( array( 'message' => $error_message ) );
			return;
		}

		if ( function_exists( 'bbai_telemetry_emit' ) ) {
			$plan_hint = isset( $_POST['plan_id'] ) ? sanitize_key( wp_unslash( $_POST['plan_id'] ) ) : '';
			bbai_telemetry_emit(
				'checkout_session_created',
				array(
					'source'        => 'stripe_checkout',
					'plan_selected' => $plan_hint,
				)
			);
		}

		wp_send_json_success(
			array(
				'url'        => $result['url'] ?? '',
				'session_id' => $result['sessionId'] ?? '',
			)
		);
	}

	/**
	 * AJAX handler: Create customer portal session
	 */
	public function ajax_create_portal() {
		$action = 'beepbeepai_nonce';
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ?? '' ) ), $action ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid nonce.', 'beepbeep-ai-alt-text-generator' ) ), 403 );
			return;
		}
		if ( ! $this->user_can_manage() ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized', 'beepbeep-ai-alt-text-generator' ) ) );
			return;
		}

		$is_authenticated       = $this->api_client->is_authenticated();
		$is_admin_authenticated = $this->is_admin_authenticated();
		$has_agency_license     = false;

		if ( $is_admin_authenticated || ! $is_authenticated ) {
			$has_license = $this->api_client->has_active_license();
			if ( $has_license ) {
				$license_data = $this->api_client->get_license_data();
				if ( $license_data && isset( $license_data['organization'] ) ) {
					$license_plan       = strtolower( $license_data['organization']['plan'] ?? 'free' );
					$has_agency_license = ( 'agency' === $license_plan || 'pro' === $license_plan );
				}
			}
		}

		if ( ! $is_authenticated && ! ( $is_admin_authenticated && $has_agency_license ) ) {
			wp_send_json_error(
				array(
					'message' => __( 'Please log in to manage billing', 'beepbeep-ai-alt-text-generator' ),
					'code'    => 'not_authenticated',
				)
			);
			return;
		}

		if ( $is_admin_authenticated && $has_agency_license && ! $is_authenticated ) {
			$stored_portal_url = Usage_Tracker::get_billing_portal_url();
			if ( ! empty( $stored_portal_url ) ) {
				wp_send_json_success( array( 'url' => $stored_portal_url ) );
				return;
			}
		}

		$return_url = admin_url( 'upload.php?page=bbai' );
		$result     = $this->api_client->create_customer_portal_session( $return_url );

		if ( is_wp_error( $result ) ) {
			$error_message = $result->get_error_message();
			$error_message = is_string( $error_message ) ? $error_message : '';
			if ( is_string( $error_message ) && $error_message && (
				strpos( (string) $error_message, 'Authentication required' ) !== false ||
				strpos( (string) $error_message, 'Unauthorized' ) !== false ||
				strpos( (string) $error_message, 'not_authenticated' ) !== false
			) ) {
				wp_send_json_error(
					array(
						'message' => __( 'To manage your subscription, please log in with your account credentials (not just admin access). If you have an agency license, contact support to access billing management.', 'beepbeep-ai-alt-text-generator' ),
						'code'    => 'not_authenticated',
					)
				);
				return;
			}
			wp_send_json_error( array( 'message' => $error_message ) );
			return;
		}

		wp_send_json_success( array( 'url' => $result['url'] ?? '' ) );
	}

	/**
	 * AJAX handler: Get subscription information
	 */
	public function ajax_get_subscription_info() {
		$action = 'beepbeepai_nonce';
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ?? '' ) ), $action ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid nonce.', 'beepbeep-ai-alt-text-generator' ) ), 403 );
			return;
		}
		if ( ! $this->user_can_manage() ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized', 'beepbeep-ai-alt-text-generator' ) ) );
			return;
		}

		if ( ! $this->api_client->is_authenticated() ) {
			wp_send_json_error(
				array(
					'message' => __( 'Please log in to view subscription information', 'beepbeep-ai-alt-text-generator' ),
					'code'    => 'not_authenticated',
				)
			);
			return;
		}

		$subscription_info = $this->api_client->get_subscription_info();

		if ( is_wp_error( $subscription_info ) ) {
			wp_send_json_error( array( 'message' => $subscription_info->get_error_message() ) );
			return;
		}

		wp_send_json_success( $subscription_info );
	}
}
