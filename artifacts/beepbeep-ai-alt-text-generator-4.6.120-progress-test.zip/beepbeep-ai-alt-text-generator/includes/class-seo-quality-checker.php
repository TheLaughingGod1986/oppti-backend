<?php
/**
 * SEO Quality Checker
 *
 * Validates alt text against SEO best practices for Google Images optimization
 *
 * @package BeepBeepAI_AltText
 * @since 4.2.4
 */

if (!defined('ABSPATH')) {
    exit;
}

class BBAI_SEO_Quality_Checker {

    /**
     * Check if alt text starts with redundant phrases
     *
     * @param string $text The alt text to check
     * @return bool
     */
    public static function has_redundant_prefix($text) {
        if (empty($text)) {
            return false;
        }

        $lower_text = strtolower(trim($text));
        $redundant_prefixes = [
            'image of',
            'picture of',
            'photo of',
            'photograph of',
            'graphic of',
            'illustration of',
            'image showing',
            'picture showing',
            'photo showing',
            'its a photo of',
            "it's a photo of",
            'its an image of',
            "it's an image of",
            'its a picture of',
            "it's a picture of",
            'a photo of',
            'an image of',
            'a picture of',
        ];

        foreach ($redundant_prefixes as $prefix) {
            if (str_starts_with($lower_text, $prefix)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check if alt text is just a filename
     *
     * @param string $text The alt text to check
     * @return bool
     */
    public static function is_just_filename($text) {
        if (empty($text)) {
            return false;
        }

        $trimmed = trim($text);

        // Check for common filename patterns
        $filename_patterns = [
            '/^IMG[-_]\d+/i',           // IMG_1234, IMG-5678
            '/^DSC[-_]\d+/i',           // DSC_1234, DSC-5678
            '/^\d{8}[-_]\d+/i',         // 20230101_123456
            '/^screenshot[-_]/i',       // screenshot_2023
            '/^image[-_]\d+/i',         // image_001, image-02
            '/\.(jpg|jpeg|png|gif|webp)$/i',  // ends with file extension
        ];

        foreach ($filename_patterns as $pattern) {
            if (preg_match($pattern, $trimmed)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Check if alt text has meaningful descriptive content
     *
     * @param string $text The alt text to check
     * @return bool
     */
    public static function has_descriptive_content($text) {
        if (empty($text)) {
            return false;
        }

        // Should have at least 3 words for meaningful description
        $words = preg_split('/\s+/', trim($text));
        if (count($words) < 3) {
            return false;
        }

        // Check if at least one word is substantial (>3 characters)
        foreach ($words as $word) {
            if (strlen($word) > 3) {
                return true;
            }
        }

        return false;
    }

    /**
     * Calculate SEO quality score for alt text.
     *
     * Delegates to the unified BBAI_Alt_Quality_Scorer engine so that
     * hard-fail rules and weighted scoring are applied consistently.
     *
     * @param string $text The alt text to check
     * @return array {
     *     @type int    $score  Quality score (0-100)
     *     @type string $grade  Letter grade (A-F)
     *     @type array  $issues List of quality issues
     *     @type string $badge  Badge type (excellent|good|fair|poor|needs-work|missing)
     * }
     */
    public static function calculate_quality($text) {
        if (empty($text) || trim($text) === '') {
            return [
                'score' => 0,
                'grade' => 'F',
                'issues' => [__('No alt text provided', 'beepbeep-ai-alt-text-generator')],
                'badge' => 'missing',
            ];
        }

        // Load unified scorer if not already loaded.
        if (!class_exists('BBAI_Alt_Quality_Scorer')) {
            $scorer_path = defined('BEEPBEEP_AI_PLUGIN_DIR')
                ? BEEPBEEP_AI_PLUGIN_DIR . 'includes/class-alt-quality-scorer.php'
                : dirname(__FILE__) . '/class-alt-quality-scorer.php';
            if (file_exists($scorer_path)) {
                require_once $scorer_path;
            }
        }

        if (class_exists('BBAI_Alt_Quality_Scorer')) {
            $result = BBAI_Alt_Quality_Scorer::score($text);
            return [
                'score'  => $result['score'],
                'grade'  => $result['grade'],
                'issues' => $result['issues'],
                'badge'  => $result['badge'],
            ];
        }

        // Fallback: should not happen, but keeps backward compat.
        return [
            'score'  => 50,
            'grade'  => 'C',
            'issues' => [__('Unable to evaluate quality', 'beepbeep-ai-alt-text-generator')],
            'badge'  => 'fair',
        ];
    }

    /**
     * Generate SEO quality badge HTML with detailed tooltip breakdown
     *
     * @param string $text The alt text to check
     * @return string HTML for quality badge
     */
    public static function create_badge($text) {
        $quality = self::calculate_quality($text);

        if ($quality['badge'] === 'missing') {
            return '';
        }

        $char_count = mb_strlen($text);
        $badge_class = 'bbai-seo-badge bbai-seo-badge--' . esc_attr($quality['badge']);

        // Build detailed tooltip content
        $tooltip = self::build_tooltip_content($text, $quality, $char_count);

        return sprintf(
            '<span class="%s" data-bbai-tooltip="%s" data-bbai-tooltip-position="top">SEO: %s</span>',
            $badge_class,
            esc_attr($tooltip),
            esc_html($quality['grade'])
        );
    }

    /**
     * Build detailed tooltip content for SEO quality badge
     *
     * @param string $text The alt text
     * @param array $quality Quality data from calculate_quality()
     * @param int $char_count Character count
     * @return string Formatted tooltip content
     */
    private static function build_tooltip_content($text, $quality, $char_count) {
        $lines = [];

        // Header with grade and score
        $lines[] = sprintf(
            /* translators: 1: grade, 2: score */
            __('SEO Score: %1$s (%2$d/100)', 'beepbeep-ai-alt-text-generator'),
            $quality['grade'],
            $quality['score']
        );
        $lines[] = '';

        // Character length check
        $length_status = $char_count <= 125 ? '✓' : '✗';
        $length_label = $char_count <= 125
            ? __('Optimal length', 'beepbeep-ai-alt-text-generator')
            : __('Too long', 'beepbeep-ai-alt-text-generator');
        $lines[] = sprintf('%s %s (%d/125)', $length_status, $length_label, $char_count);

        // Redundant prefix check
        $has_prefix = self::has_redundant_prefix($text);
        $prefix_status = $has_prefix ? '✗' : '✓';
        $prefix_label = $has_prefix
            ? __('Remove "image of" prefix', 'beepbeep-ai-alt-text-generator')
            : __('No redundant prefix', 'beepbeep-ai-alt-text-generator');
        $lines[] = sprintf('%s %s', $prefix_status, $prefix_label);

        // Filename check
        $is_filename = self::is_just_filename($text);
        $filename_status = $is_filename ? '✗' : '✓';
        $filename_label = $is_filename
            ? __('Looks like a filename', 'beepbeep-ai-alt-text-generator')
            : __('Descriptive text', 'beepbeep-ai-alt-text-generator');
        $lines[] = sprintf('%s %s', $filename_status, $filename_label);

        // Descriptive content check
        $is_descriptive = self::has_descriptive_content($text);
        $descriptive_status = $is_descriptive ? '✓' : '✗';
        $descriptive_label = $is_descriptive
            ? __('Good keyword content', 'beepbeep-ai-alt-text-generator')
            : __('Needs more detail', 'beepbeep-ai-alt-text-generator');
        $lines[] = sprintf('%s %s', $descriptive_status, $descriptive_label);

        // Add tip for non-A grades
        if ($quality['grade'] !== 'A') {
            $lines[] = '';
            $lines[] = __('Tip: Regenerate for better SEO', 'beepbeep-ai-alt-text-generator');
        }

        return implode("\n", $lines);
    }

    /**
     * Generate unified SEO quality badge HTML combining grade and character count
     *
     * This is the preferred method for displaying SEO quality - it shows a single
     * badge with the grade and character count, with a detailed tooltip breakdown.
     *
     * @param string $text The alt text to check
     * @return string HTML for unified quality badge
     * @since 5.0.0
     */
    public static function create_unified_badge($text) {
        $quality = self::calculate_quality($text);

        // For missing alt text, return a dash indicator
        if ($quality['badge'] === 'missing') {
            return '<span class="bbai-seo-unified-badge bbai-seo-unified-badge--empty" data-bbai-tooltip="' . esc_attr__('No alt text', 'beepbeep-ai-alt-text-generator') . '">—</span>';
        }

        $char_count = mb_strlen($text);
        $badge_class = 'bbai-seo-unified-badge bbai-seo-unified-badge--' . esc_attr($quality['badge']);

        // Build detailed tooltip content
        $tooltip = self::build_tooltip_content($text, $quality, $char_count);

        // Format: "A (84)" - grade with character count
        return sprintf(
            '<span class="%s" data-bbai-tooltip="%s" data-bbai-tooltip-position="top">%s <span class="bbai-seo-unified-badge__chars">(%d)</span></span>',
            $badge_class,
            esc_attr($tooltip),
            esc_html($quality['grade']),
            $char_count
        );
    }
}
