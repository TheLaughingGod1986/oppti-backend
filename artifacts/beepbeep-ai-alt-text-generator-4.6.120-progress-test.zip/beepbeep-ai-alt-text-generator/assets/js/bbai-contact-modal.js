/**
 * BeepBeep AI Contact Modal
 * Contact form modal for user support requests via Resend API
 *
 * @package BeepBeep_AI_Alt_Text_Generator
 * @since 6.0.0
 */

(function($) {
    'use strict';

    const i18n = window.wp && window.wp.i18n ? window.wp.i18n : null;
    const __ = i18n && typeof i18n.__ === 'function' ? i18n.__ : (text) => text;

    /**
     * Contact Modal Class
     */
    class BBaiContactModal {
        constructor() {
            this.modal = null;
            this.form = null;
            this.isOpen = false;
            this.init();
        }

        /**
         * Initialize contact modal
         */
        init() {
            this.createModal();
            this.bindEvents();
        }

        /**
         * Create modal HTML structure
         */
        createModal() {
            if ($('#bbai-contact-modal-overlay').length > 0) {
                return; // Already exists
            }

            const modalHTML = `
                <div id="bbai-contact-modal-overlay" class="bbai-contact-modal-overlay" role="dialog" aria-modal="true" aria-labelledby="bbai-contact-modal-title" style="display: none;">
                    <div class="bbai-contact-modal-backdrop"></div>
                    <div class="bbai-contact-modal-container">
                        <div class="bbai-contact-modal-content">
                            <div class="bbai-contact-modal-header">
                                <h2 id="bbai-contact-modal-title" class="bbai-contact-modal-title">${__('Contact Us', 'beepbeep-ai-alt-text-generator')}</h2>
                                <button type="button" class="bbai-contact-modal-close" aria-label="${__('Close modal', 'beepbeep-ai-alt-text-generator')}">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <path d="M18 6L6 18M6 6l12 12"/>
                                    </svg>
                                </button>
                            </div>
                            <form id="bbai-contact-form" class="bbai-contact-form">
                                <div class="bbai-contact-form-group">
                                    <label for="bbai-contact-name" class="bbai-contact-form-label">
                                        ${__('Name', 'beepbeep-ai-alt-text-generator')} <span class="bbai-contact-form-required">*</span>
                                    </label>
                                    <input 
                                        type="text" 
                                        id="bbai-contact-name" 
                                        name="name" 
                                        class="bbai-contact-form-input" 
                                        required 
                                        placeholder="${__('Your name', 'beepbeep-ai-alt-text-generator')}"
                                    />
                                </div>
                                <div class="bbai-contact-form-group">
                                    <label for="bbai-contact-email" class="bbai-contact-form-label">
                                        ${__('Email', 'beepbeep-ai-alt-text-generator')} <span class="bbai-contact-form-required">*</span>
                                    </label>
                                    <input 
                                        type="email" 
                                        id="bbai-contact-email" 
                                        name="email" 
                                        class="bbai-contact-form-input" 
                                        required 
                                        placeholder="${__('your@email.com', 'beepbeep-ai-alt-text-generator')}"
                                    />
                                </div>
                                <div class="bbai-contact-form-group">
                                    <label for="bbai-contact-subject" class="bbai-contact-form-label">
                                        ${__('Subject', 'beepbeep-ai-alt-text-generator')} <span class="bbai-contact-form-required">*</span>
                                    </label>
                                    <input 
                                        type="text" 
                                        id="bbai-contact-subject" 
                                        name="subject" 
                                        class="bbai-contact-form-input" 
                                        required 
                                        placeholder="${__('How can we help?', 'beepbeep-ai-alt-text-generator')}"
                                    />
                                </div>
                                <div class="bbai-contact-form-group">
                                    <label for="bbai-contact-message" class="bbai-contact-form-label">
                                        ${__('Message', 'beepbeep-ai-alt-text-generator')} <span class="bbai-contact-form-required">*</span>
                                    </label>
                                    <textarea 
                                        id="bbai-contact-message" 
                                        name="message" 
                                        class="bbai-contact-form-textarea bbai-textarea" 
                                        required 
                                        rows="5"
                                        placeholder="${__('Please describe your issue or question...', 'beepbeep-ai-alt-text-generator')}"
                                    ></textarea>
                                </div>
                                <div class="bbai-contact-form-info">
                                    <p class="bbai-contact-form-info-text">
                                        ${__('Your system information (WordPress version, Plugin version) will be automatically included.', 'beepbeep-ai-alt-text-generator')}
                                    </p>
                                </div>
                                <div id="bbai-contact-form-error" class="bbai-contact-form-error" style="display: none;"></div>
                                <div id="bbai-contact-form-success" class="bbai-contact-form-success" style="display: none;"></div>
                                <div class="bbai-contact-form-actions">
                                    <button type="button" class="bbai-btn bbai-btn-secondary" data-action="close-contact-modal">
                                        ${__('Cancel', 'beepbeep-ai-alt-text-generator')}
                                    </button>
                                    <button type="submit" class="bbai-btn bbai-btn-primary" id="bbai-contact-submit">
                                        ${__('Send Message', 'beepbeep-ai-alt-text-generator')}
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            `;

            $('body').append(modalHTML);
            this.modal = $('#bbai-contact-modal-overlay');
            this.form = $('#bbai-contact-form');
        }

        /**
         * Bind events
         */
        bindEvents() {
            const self = this;

            // Open modal triggers
            $(document).on('click', '[data-action="open-contact-modal"], .bbai-contact-link', function(e) {
                e.preventDefault();
                self.open(this);
            });

            // Close modal
            $(document).on('click', '.bbai-contact-modal-backdrop, .bbai-contact-modal-close, [data-action="close-contact-modal"]', function(e) {
                e.preventDefault();
                self.close();
            });

            // ESC key to close
            $(document).on('keydown', function(e) {
                if (e.key === 'Escape' && self.isOpen) {
                    self.close();
                }
            });

            // Form submission
            this.form.on('submit', function(e) {
                e.preventDefault();
                self.handleSubmit();
            });

            // Clear errors on input
            this.form.find('input, textarea').on('input', function() {
                self.hideError();
                self.hideSuccess();
            });
        }

        /**
         * Open modal
         */
        open(trigger) {
            if (this.isOpen) {
                return;
            }

            // Populate system info (hidden fields or add to form data)
            const wpVersion = typeof window.bbaiContactData !== 'undefined' && window.bbaiContactData.wp_version 
                ? window.bbaiContactData.wp_version 
                : '';
            const pluginVersion = typeof window.bbaiContactData !== 'undefined' && window.bbaiContactData.plugin_version 
                ? window.bbaiContactData.plugin_version 
                : '';

            // Store in form data (will be sent with submission)
            this.form.data('wp_version', wpVersion);
            this.form.data('plugin_version', pluginVersion);

            // Reset form
            this.form[0].reset();
            this.hideError();
            this.hideSuccess();
            this.prefillFromContactData();
            this.prefillFromTrigger(trigger);

            // Show modal
            this.modal.fadeIn(200);
            this.isOpen = true;

            // Focus first input
            setTimeout(() => {
                $('#bbai-contact-name').focus();
            }, 200);

            // Prevent body scroll
            $('body').css('overflow', 'hidden');
        }

        prefillFromTrigger(trigger) {
            const source = trigger && trigger.getAttribute ? trigger : null;
            const subject = source ? (source.getAttribute('data-bbai-contact-subject') || '') : '';
            const message = source ? (source.getAttribute('data-bbai-contact-message') || '') : '';

            if (subject) {
                $('#bbai-contact-subject').val(subject);
            }
            if (message) {
                $('#bbai-contact-message').val(message);
            }
        }

        prefillFromContactData() {
            const data = typeof window.bbaiContactData !== 'undefined' ? window.bbaiContactData : {};
            if (data.user_name) {
                $('#bbai-contact-name').val(data.user_name);
            }
            if (data.user_email) {
                $('#bbai-contact-email').val(data.user_email);
            }
        }

        /**
         * Close modal
         */
        close() {
            if (!this.isOpen) {
                return;
            }

            this.modal.fadeOut(200);
            this.isOpen = false;

            // Restore body scroll
            $('body').css('overflow', '');
        }

        /**
         * Handle form submission
         */
        handleSubmit() {
            const self = this;
            const submitButton = $('#bbai-contact-submit');
            const formData = {
                name: $('#bbai-contact-name').val().trim(),
                email: $('#bbai-contact-email').val().trim(),
                subject: $('#bbai-contact-subject').val().trim(),
                message: $('#bbai-contact-message').val().trim(),
                wp_version: this.form.data('wp_version') || '',
                plugin_version: this.form.data('plugin_version') || ''
            };

            // Client-side validation
            if (!formData.name || !formData.email || !formData.subject || !formData.message) {
                this.showError(__('Please fill in all required fields.', 'beepbeep-ai-alt-text-generator'));
                return;
            }

            if (!this.isValidEmail(formData.email)) {
                this.showError(__('Please enter a valid email address.', 'beepbeep-ai-alt-text-generator'));
                return;
            }

            // Disable submit button
            submitButton.prop('disabled', true).text(__('Sending...', 'beepbeep-ai-alt-text-generator'));
            this.hideError();
            this.hideSuccess();

            // Get AJAX config
            const ajaxConfig = typeof window.bbai_ajax !== 'undefined' ? window.bbai_ajax : 
                               (typeof bbai_ajax !== 'undefined' ? bbai_ajax : null);

            if (!ajaxConfig || !ajaxConfig.ajaxurl) {
                this.showError(__('Configuration error. Please refresh the page and try again.', 'beepbeep-ai-alt-text-generator'));
                submitButton.prop('disabled', false).text(__('Send Message', 'beepbeep-ai-alt-text-generator'));
                return;
            }

            // Prepare AJAX request
            const requestData = {
                action: 'bbai_send_contact_form',
                nonce: ajaxConfig.nonce || '',
                ...formData
            };

            // Send AJAX request
            $.ajax({
                url: ajaxConfig.ajaxurl,
                type: 'POST',
                data: requestData,
                success: function(response) {
                    if (response && response.success) {
                        const successMessage = response.data && response.data.message 
                            ? response.data.message 
                            : __("Your message has been sent successfully. We'll get back to you soon!", 'beepbeep-ai-alt-text-generator');

                        self.updateLastContactedSupport(response.data && response.data.last_contacted_support);
                        self.showSubmittedState(successMessage);
                    } else {
                        const errorMessage = response && response.data && response.data.message 
                            ? response.data.message 
                            : __('Failed to send message. Please try again.', 'beepbeep-ai-alt-text-generator');
                        if (self.isSavedMailDeliveryError(errorMessage)) {
                            self.showSubmittedState(__('Your message has been saved. This WordPress site could not send email automatically, so please email benoats86@gmail.com if the issue is urgent.', 'beepbeep-ai-alt-text-generator'));
                            submitButton.prop('disabled', false).text(__('Send Message', 'beepbeep-ai-alt-text-generator'));
                            return;
                        }
                        self.showError(errorMessage);
                    }
                    submitButton.prop('disabled', false).text(__('Send Message', 'beepbeep-ai-alt-text-generator'));
                },
                error: function(xhr, status, error) {
                    window.BBAI_LOG && window.BBAI_LOG.error('Contact form submission error:', error);
                    self.showError(__('Network error. Please check your connection and try again.', 'beepbeep-ai-alt-text-generator'));
                    submitButton.prop('disabled', false).text(__('Send Message', 'beepbeep-ai-alt-text-generator'));
                }
            });
        }

        isSavedMailDeliveryError(message) {
            const normalized = String(message || '').toLowerCase();
            return normalized.includes('could not send the support email')
                || normalized.includes('wordpress mail delivery')
                || normalized.includes('bbai_support_mail_failed');
        }

        updateLastContactedSupport(lastContactedSupport) {
            const label = lastContactedSupport && lastContactedSupport.label ? String(lastContactedSupport.label) : '';
            if (!label) {
                return;
            }

            $('[data-bbai-support-last-contact]').each(function() {
                $(this).text(label).prop('hidden', false).removeAttr('hidden');
            });
        }

        showSubmittedState(message) {
            this.form.find('.bbai-contact-form-group').hide();
            this.form.find('.bbai-contact-form-actions').hide();
            this.form.find('.bbai-contact-form-info').hide();

            const successHeading = __('Saved', 'beepbeep-ai-alt-text-generator');
            this.showSuccess('<strong style="font-size: 16px; display: block; margin-bottom: 8px;">✓ ' + successHeading + '</strong>' + message);

            const formContainer = this.modal.find('.bbai-contact-form');
            if (formContainer.length) {
                formContainer.scrollTop(0);
            }

            setTimeout(() => {
                this.form[0].reset();
                this.form.find('.bbai-contact-form-group').show();
                this.form.find('.bbai-contact-form-actions').show();
                this.form.find('.bbai-contact-form-info').show();
                this.hideSuccess();
                this.close();
            }, 3000);
        }

        /**
         * Validate email format
         */
        isValidEmail(email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        }

        /**
         * Show error message
         */
        showError(message) {
            const errorDiv = $('#bbai-contact-form-error');
            errorDiv.text(message).fadeIn(200);
            // Scroll to error
            $('html, body').animate({
                scrollTop: errorDiv.offset().top - 100
            }, 300);
        }

        /**
         * Hide error message
         */
        hideError() {
            $('#bbai-contact-form-error').fadeOut(200);
        }

        /**
         * Show success message
         */
        showSuccess(message) {
            const successDiv = $('#bbai-contact-form-success');
            successDiv.html(message).fadeIn(200);
            
            // Scroll success message into view within the modal
            const modalContent = this.modal.find('.bbai-contact-modal-content');
            const successOffset = successDiv.offset();
            const modalOffset = modalContent.offset();
            
            if (successOffset && modalOffset) {
                // Scroll within the modal's scrollable container
                const formContainer = this.modal.find('.bbai-contact-form');
                if (formContainer.length) {
                    const scrollTop = formContainer.scrollTop();
                    const elementTop = successDiv.position().top;
                    formContainer.scrollTop(scrollTop + elementTop - 20);
                }
            }
        }

        /**
         * Hide success message
         */
        hideSuccess() {
            $('#bbai-contact-form-success').fadeOut(200);
        }
    }

    // Initialize contact modal when DOM is ready
    $(document).ready(function() {
        if (typeof window.bbaiContactModal === 'undefined') {
            window.bbaiContactModal = new BBaiContactModal();
        }
    });

})(jQuery);
